exports.handler = async (event, context) => {
    throw Exception('error from lambda code')
}